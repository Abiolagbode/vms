<?php
$con=mysqli_connect("http://casvms.epizy.com", "epiz_24747596", "Cas2012", "epiz_24747596_cvms");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
